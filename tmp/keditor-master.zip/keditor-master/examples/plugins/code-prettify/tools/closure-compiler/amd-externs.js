/**
 * @param {string} id
 * @param {Array.<string>} dependencies
 * @param {Function} factory
 */
function define(id, dependencies, factory) {}
/** @type {*} */
define.amd;
