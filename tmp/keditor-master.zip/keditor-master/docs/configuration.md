# Configuration
See [source code](../src/keditor/constants/defaults.js) for more details and default configuration.

 ---
[⬅ Back to documentation list](../README.md#documentation)
